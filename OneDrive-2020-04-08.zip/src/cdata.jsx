export function getData() {
    return [
        { id: 11, color: 'White'},
        { id: 12, color: 'Black'},
        { id: 13, color: 'Gray'},
        { id: 14, color: 'Gold'},
        { id: 15, color: 'Red'},
        { id: 16, color: 'Purple'},
        { id: 17, color: 'Silver'},
        { id: 18, color: 'Orange'},
        { id: 19, color: 'Brown'},
        { id: 20, color: 'Green'},
        { id: 21, color: 'Blue'},

    ];
}
