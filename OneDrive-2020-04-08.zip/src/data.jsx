export function getData() {
    return [
        { id: 1, class: 'Passenger Car'},
        { id: 2, class: 'SUV/4WD'},
        { id: 3, class: 'Traller'},
        { id: 4, class: 'Boat/Jetski' },
        { id: 5, class: 'Motorcycle'},
        { id: 6, class: 'Caravan'},
        { id: 7, class: 'Truck'},
    ];
}
